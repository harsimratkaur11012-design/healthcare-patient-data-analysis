import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/healthcare_patients_raw.csv")

print("RAW SHAPE:", df.shape)
print("\nDATA TYPES:\n", df.dtypes)
print("\nMISSING VALUES:\n", df.isna().sum())
print("\nDUPLICATES:", df.duplicated().sum())

# Cleaning
df = df.drop_duplicates()
for col in ["age", "systolic_bp", "heart_rate_bpm"]:
    df[col] = df[col].fillna(df[col].median())
for col in ["medication", "gender", "disease"]:
    df[col] = df[col].fillna(df[col].mode()[0])

print("\nCLEAN SHAPE:", df.shape)

# Basic analysis
print("\nUNIQUE PATIENTS:", df["patient_id"].nunique())
print("AVERAGE AGE:", round(df["age"].mean(), 2))
print("\nCOMMON DISEASES:\n", df["disease"].value_counts())
print("\nMEDICATION FREQUENCY:\n", df["medication"].value_counts())

# Charts
plt.figure(figsize=(9,5))
df["disease"].value_counts().sort_values().plot(kind="barh")
plt.title("Disease Distribution")
plt.xlabel("Patients")
plt.tight_layout()
plt.savefig("outputs/disease_distribution.png", dpi=180)
plt.close()

plt.figure(figsize=(9,5))
df.groupby("disease")["age"].mean().sort_values().plot(kind="bar")
plt.title("Average Age by Disease")
plt.ylabel("Average Age")
plt.xticks(rotation=35, ha="right")
plt.tight_layout()
plt.savefig("outputs/average_age_by_disease.png", dpi=180)
plt.close()

df.to_csv("data/healthcare_patients_cleaned.csv", index=False)
print("\nSaved cleaned dataset and charts.")
