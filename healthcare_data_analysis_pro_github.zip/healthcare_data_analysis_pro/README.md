# Healthcare Patient Data Analysis

A portfolio-ready **Python + Pandas healthcare analytics project** using 750 synthetic patient records.

## Project objectives
- Explore patient demographics and clinical variables
- Identify numerical and categorical columns
- Detect missing and duplicate records
- Clean healthcare data using median/mode imputation
- Calculate unique patient count and average age
- Identify common diseases and medications
- Compare average age across diseases
- Create basic healthcare visualizations

## Dataset
The project contains synthetic data for educational purposes only. No real patient information is used.

Columns:
- `patient_id`
- `age`
- `gender`
- `disease`
- `medication`
- `dosage_mg`
- `systolic_bp`
- `heart_rate_bpm`
- `follow_up_days`

## Data-cleaning workflow
1. Load CSV with Pandas
2. Inspect shape and data types
3. Detect missing values
4. Detect duplicate records
5. Remove duplicate rows
6. Fill numerical missing values with median
7. Fill categorical missing values with mode
8. Perform descriptive analysis
9. Generate charts
10. Export cleaned dataset

## Run
```bash
pip install -r requirements.txt
python analysis.py
```

## Skills
Python | Pandas | NumPy | Data Cleaning | Healthcare Analytics | Descriptive Statistics | Data Visualization

## Portfolio description
> An end-to-end healthcare data analysis project using Python and Pandas to clean, explore, and analyze synthetic patient records, identify disease and medication patterns, calculate demographic statistics, and generate healthcare-focused visualizations.

## Important
This dataset is synthetic and must not be presented as real patient or clinical data.
